import java.awt.Color;
import java.util.*;
import java.io.*;

import comp102.*;

public class TwitterCloud implements UIButtonListener {

    //fields
    /** wordFrequencey is a Map from words to integers,
     * for each word, it contains the frequency of the word (how many times
     * it occurred in the file) */ 
    private Map<String, Integer> wordFrequency;

    /** wordIndex is a Map from words to list of tweets:
	for each word, it contains the list of tweets that the word was found in */
    private Map<String, List<String>> wordIndex;

    //Constructor. Sets up the user interface.
    public TwitterCloud() {
	UI.addButton("Read File", this);    // read file of tweets and construct maps
	UI.addButton("Draw Cloud", this);   // draw a cloud of words based on frequency
	UI.addButton("Search", this);       // list the tweets containing a given word
    }

    /** Responds to the buttons */
    public void buttonPerformed(String button) {
	// YOUR CODE HERE
    }
    
    /** Initialises the fields to empty HashMap's, and reads a file of tweets,
	constructing the wordFrequency map (core) and
	the wordIndex map (completion).
	Reads each tweet as a whole line from the file.
	For each tweet, wraps the tweet in a Scanner, and reads each word from the tweet.
	For each word, increments its count in the wordFrequency table,
	and (for the completion) adds the tweet to the words' entry in the wordIndex map.
*/
    private void readTweetFile(String filename){
	try{
	    Scanner input = new Scanner(new FileInputStream(filename));	
	    // YOUR CODE HERE
	}
	catch(IOException e){System.out.println("Fail: " + e);}
    }


    /** Draws a "cloud" of all the more frequent words.
	For each word in the wordFrequency map, whose frequency is above
	some threshold, draw the word with a size and color that depends
	on the frequency of the word, at a random position on the graphics pane.
*/
    public void drawCloud() {
	int cloudLeft = 20;  // left and top of the cloud 
	int cloudTop = 40;   
	int cloudWidth = UI.getCanvasWidth() - 60;   // width and height of cloud
	int cloudHeight = UI.getCanvasHeight() - 20;
	// YOUR CODE HERE
    }


    /** Sets the font size and the colour, depending on the argument.
	The higher the frequency, the larger the size and the darker the colour.
     */
    private void setSizeAndColor(int freq){
	int fontSize = 5;
	Color color = Color.LIGHT_GRAY;
	if (freq >= 10000) {
	    color = Color.BLUE;
	    fontSize = 48;
	}
	else if (freq >= 1000) {
	    color = Color.BLACK;
	    fontSize = 36;
	}
	else if (freq >= 100) {
	    color = Color.DARK_GRAY;
	    fontSize = 24;
	}
	else if (freq >= 10) {
	    color = Color.GRAY;
	    fontSize = 10;
	} 
	UI.setFontSize(fontSize);
	UI.setColor(color);
    }


    /** Prints all the tweets that contain a given word.
	Asks the user for a word, and then looks it up in the wordIndex
	to find the list of tweets.
     */
    private void searchTweets(String word){
	// YOUR CODE HERE
    }




    public static void main(String[] args) {
	TwitterCloud tc = new TwitterCloud();
    }
}
