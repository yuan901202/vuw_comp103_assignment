/* Code for COMP 103 Assignment 10
 * Name:
 * Usercode:
 * ID:
 */

import java.util.*;

public class HeapArrayQueue <E extends Comparable<? super E> > extends AbstractQueue <E> {

    // YOUR CODE HERE
}
